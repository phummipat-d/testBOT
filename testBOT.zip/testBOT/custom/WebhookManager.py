
#ไฟล์นี้จะเป็นไฟล์เริ่มต้นสำหรับการพัฒนาระบบ
#ตัวแปร payload คือข้อมูลที่ถูกส่งมาจากฝั่งผู้ใช้งาน(LineApp)
#การตอบกลับข้อมูลไปให้ผู้ใช้งานฝั้ง LineApp แบบพื้นฐานเช่น ข้อมูล,ภาพ ฯลฯ จะใช้การ Reply ผ่าน basic packages (BasicReplyMessage)
#การตอบกลับข้อมูลไปให้ผู้ใช้งานฝั้ง LineApp ในรูปแบบที่ซับซ้อนมากขึ้น เช่น FlexMessage จะใช้การ Reply ผ่าน custom packages

from custom.Config import *
from basic.BasicReplyMessage import *
from custom.ReplyFlexMessage import *
from custom.QuickReplyButtons import *

def manage(line_bot_api,payload):
    print(payload)
    message_type = payload['events'][0]['message']['type']
    replyToken = payload['events'][0]['replyToken']

    #กรณีผู้ใช้งานส่งข้อความเป็น text
    if message_type == "text":
        try:
            #รับข้อความที่ได้จากผู้ใช้งาน
            #txtMessage = payload['events'][0]['message']['text']
            #txtMessage = "Hi,your message is : " + payload['events'][0]['message']['text']
            #ReplyTextMessage(line_bot_api,replyToken, txtMessage )

            txtMessage = payload["events"][0]["message"]["text"]
            from db.Shop import select
            result = select(txtMessage)  
            ReplyTextMessage(line_bot_api,replyToken, result )

            '''
            txtMessage = payload["events"][0]["message"]["text"]
            if txtMessage == "text":
                ReplyTextMessage(line_bot_api,replyToken, "สวัสดีครับ ยินดีต้อนรับเข้าสู่การทดลองการใช้งาน Basic Reply" )
            elif txtMessage == "image":
                ReplyImageMessage(line_bot_api,replyToken, 
                                  "https://static.line-scdn.net/linecorpweb-uit/18a975c4945/images/logo_h1_v2.png",
                                  "https://static.line-scdn.net/linecorpweb-uit/18a975c4945/images/logo_h1_v2.png")
            elif txtMessage == "sticker" :
                ReplyStickerMessage(line_bot_api,replyToken, "446","1997")
            elif txtMessage == "location" :
                ReplyLocationMessage(line_bot_api,replyToken, "ทดสอบ","ทดสอบ",15,100)
            elif txtMessage == "flex" :
                ReplyMyFlexMessage(line_bot_api,replyToken,"good")
            elif txtMessage == "Quick":
                ReplyQuickDirection(line_bot_api,replyToken,"คุณต้องการไปทางซ้ายหรือทางขวา")
            else:
                ReplyTextMessage(line_bot_api,replyToken, "ขออภัยข้อความความของท่านไม่สามารถประมวลผลได้" )
            '''

            
        except Exception as e:
            print(e)

    #กรณีผู้ใช้งานส่งข้อความเป็น image
    elif message_type == "image":
        try:
            #ทำกาบันทึกภาพที่ผู้ใช้งานส่งมา
            message_id = payload['events'][0]['message']['id']
            file_path = "media/{}.png".format(message_id)
            message_content = line_bot_api.get_message_content(message_id)
            with open(file_path, 'wb') as fd:
                for chunk in message_content.iter_content():
                    fd.write(chunk)

            #imageURL = "https://etherscan.io/images/ethereum-icon.png"
            #ReplyImageMessage(line_bot_api,replyToken, imageURL,imageURL)

            alt_text = "Tongashi Flex Message"
            ReplyFlexMessage(line_bot_api,replyToken,alt_text)
            #ReplyQuickButtons(line_bot_api,replyToken,"Title QuickButtons")

        except Exception as e:
            print(e) 

    elif message_type == "location":
         longitude = payload['events'][0]['message']['longitude']
         latitude = payload['events'][0]['message']['latitude']
         txtMessage = "your location is : ("+str(longitude)+","+str(latitude)+")" 
         ReplyTextMessage(line_bot_api,replyToken, txtMessage )
    

    
    return 200