#bot information
BASIC_ID = "@123kpuhy"
CHANNEL_SECRET = "d42a6eeb9edfbd243f3f909e99fa5385"
CHANNEL_ACCESS_TOKEN = "lB0EA2k1fPGv+6XDeHhODLpZUUGl13wX819dvUxu5MO6+0jAavmVGwkV1ltXntiditL6uC4avBSCH3JJskUKffFFYAM+t+yOLGBA0PInTdy2Qoh4UsaFKrU55JUBZ/9YkokEki+ezT0ybZ3x9kNutwdB04t89/1O/w1cDnyilFU="

#ngrok information
NGROK_MODE = True
NGROK_TOKEN_API = "2VgllSMqlUHWbJVgDNzUoO9EvKl_2RAAG7dN9b34bFoVfDnsW"

#line api url
LINE_REPLY_API = 'https://api.line.me/v2/bot/message/reply'
LINE_WEBHOOK_API = "https://api.line.me/v2/bot/channel/webhook/endpoint"

#flask information
PORT = 5000
LOCAL_HOST_URL = "http://localhost:{}".format(PORT)
WEBHOOK_ROOT = "/webhook"

#service for serving media
IMAGES_ROOT = "/images"
VIDEOS_ROOT = "/videos"