from db.dbConnection import *

def select(id):
    sql = "SELECT * FROM info WHERE id = "+str(id)
    mycursor.execute(sql)
    result = mycursor.fetchall()
    return result[0][2]

#select(1)

    






